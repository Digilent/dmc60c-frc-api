#include "digilent/DMC60/DMC60C_C.h"
#include "digilent/DMC60/com_dmc60c_DMC60CJNI.h"

JNIEXPORT jint JNICALL Java_com_dmc60c_DMC60CJNI_Create
  (JNIEnv *env, jclass jcls, jint deviceNumber){
	  return (jint)c_DMC60C_Create1((int)deviceNumber);
  }


/*
 * Class:     com_dmc60c_DMC60CJNI
 * Method:    ConfigWheel
 * Signature: (IDII)V
 */
JNIEXPORT void JNICALL Java_com_dmc60c_DMC60CJNI_ConfigWheel
  (JNIEnv *env, jclass jcls, jint handle, jdouble wheelDiametermm, jdouble gearRatio, jint encoderTicks){
	  c_DMC60C_configWheel((int)handle, (double)wheelDiametermm, (double)gearRatio, (int)encoderTicks);
  }

/*
 * Class:     com_dmc60c_DMC60CJNI
 * Method:    ConfigPID
 * Signature: (IIFFFF)I
 */
JNIEXPORT jint JNICALL Java_com_dmc60c_DMC60CJNI_ConfigPID
  (JNIEnv *env, jclass jcls, jint handle, jint slot, jfloat P, jfloat I, jfloat D, jfloat F){
	  return (jint)c_DMC60C_configPID((int)handle, (int)slot, (float)P, (float)I, (float)D, (float)F);
  }

/*
 * Class:     com_dmc60c_DMC60CJNI
 * Method:    ConfigClosedLoopRampRate
 * Signature: (III)I
 */
JNIEXPORT jint JNICALL Java_com_dmc60c_DMC60CJNI_ConfigClosedLoopRampRate
  (JNIEnv *env, jclass jcls, jint handle, jint slot, jint rampRate){
	  return (jint)c_DMC60C_configClosedLoopRampRate((int)handle, (int)slot, (int)rampRate);
  }

/*
 * Class:     com_dmc60c_DMC60CJNI
 * Method:    ConfigOpenLoopRampRate
 * Signature: (IS)V
 */
JNIEXPORT void JNICALL Java_com_dmc60c_DMC60CJNI_ConfigOpenLoopRampRate
  (JNIEnv *env, jclass jcls, jint handle, jshort rampRate){
	  c_DMC60C_configOpenLoopRampRate((int)handle, (short)rampRate);
  }

/*
 * Class:     com_dmc60c_DMC60CJNI
 * Method:    SetContinuousCurrentLimit
 * Signature: (ID)I
 */
JNIEXPORT jint JNICALL Java_com_dmc60c_DMC60CJNI_SetContinuousCurrentLimit
  (JNIEnv *env, jclass jcls, jint handle, jdouble rampRate){
	return (jint)c_DMC60C_setContinuousCurrentLimit((int)handle, (short)rampRate);
}
/*
 * Class:     com_dmc60c_DMC60CJNI
 * Method:    SetPeakCurrentLimit
 * Signature: (ID)I
 */
JNIEXPORT jint JNICALL Java_com_dmc60c_DMC60CJNI_SetPeakCurrentLimit
  (JNIEnv *env, jclass jcls, jint handle, jdouble currentAmps){
	return (jint)c_DMC60C_setPeakCurrentLimit((int)handle, (double)currentAmps);
}

/*
 * Class:     com_dmc60c_DMC60CJNI
 * Method:    SetPeakCurrentDuration
 * Signature: (II)I
 */
JNIEXPORT jint JNICALL Java_com_dmc60c_DMC60CJNI_SetPeakCurrentDuration
  (JNIEnv *env, jclass jcls, jint handle, jint durationMs){
	return (jint)c_DMC60C_setPeakCurrentDuration((int)handle, (int)durationMs);
}

/*
 * Class:     com_dmc60c_DMC60CJNI
 * Method:    EnableCurrentLimiting
 * Signature: (IZ)I
 */
JNIEXPORT jint JNICALL Java_com_dmc60c_DMC60CJNI_EnableCurrentLimiting
  (JNIEnv *env, jclass jcls, jint handle, jboolean enabled){
	return (jint)c_DMC60C_enableCurrentLimiting((int)handle, (bool)enabled);
}

/*
 * Class:     com_dmc60c_DMC60CJNI
 * Method:    IsCurrentLimitActive
 * Signature: (I)Z
 */
JNIEXPORT jboolean JNICALL Java_com_dmc60c_DMC60CJNI_IsCurrentLimitActive
  (JNIEnv *env, jclass jcls, jint handle){
	return (jboolean)c_DMC60C_isCurrentLimitActive((int)handle);
}
/*
 * Class:     com_dmc60c_DMC60CJNI
 * Method:    DriveVoltage
 * Signature: (ID)V
 */
JNIEXPORT void JNICALL Java_com_dmc60c_DMC60CJNI_DriveVoltage
  (JNIEnv *env, jclass jcls, jint handle, jdouble percentVoltage){
	  c_DMC60C_driveVoltage((int)handle, (double)percentVoltage);
  }
/*
 * Class:     com_dmc60c_DMC60CJNI
 * Method:    DrivePosition
 * Signature: (ID)V
 */
JNIEXPORT void JNICALL Java_com_dmc60c_DMC60CJNI_DrivePosition
  (JNIEnv *env, jclass jcls, jint handle, jdouble revolutions){
	  c_DMC60C_drivePosition((int)handle, (double)revolutions);
  }
/*
 * Class:     com_dmc60c_DMC60CJNI
 * Method:    DriveDistance
 * Signature: (ID)V
 */
JNIEXPORT void JNICALL Java_com_dmc60c_DMC60CJNI_DriveDistance
  (JNIEnv *env, jclass jcls, jint handle, jdouble meters){
	c_DMC60C_driveDistance((int)handle, (double)meters);
}
/*
 * Class:     com_dmc60c_DMC60CJNI
 * Method:    DriveVelocity
 * Signature: (ID)V
 */
JNIEXPORT void JNICALL Java_com_dmc60c_DMC60CJNI_DriveVelocity
  (JNIEnv *env, jclass jcls, jint handle, jdouble metersPerSecond){
	  c_DMC60C_driveVelocity((int)handle, (double)metersPerSecond);
  }

/*
 * Class:     com_dmc60c_DMC60CJNI
 * Method:    DriveVoltageCompensation
 * Signature: (ID)V
 */
JNIEXPORT void JNICALL Java_com_dmc60c_DMC60CJNI_DriveVoltageCompensation
  (JNIEnv *env, jclass jcls, jint handle, jdouble voltage){
	  c_DMC60C_driveVoltageCompensation((int)handle, (double)voltage);
  }
/*
 * Class:     com_dmc60c_DMC60CJNI
 * Method:    DriveCurrent
 * Signature: (ID)V
 */
JNIEXPORT void JNICALL Java_com_dmc60c_DMC60CJNI_DriveCurrent
  (JNIEnv *env, jclass jcls, jint handle, jdouble currentAmps){
	c_DMC60C_driveCurrent((int)handle, (double)currentAmps);
}
/*
 * Class:     com_dmc60c_DMC60CJNI
 * Method:    FollowerMode
 * Signature: (II)V
 */
JNIEXPORT void JNICALL Java_com_dmc60c_DMC60CJNI_FollowerMode
  (JNIEnv *env, jclass jcls, jint handle, jint deviceNumbertoFollow){
	  c_DMC60C_followerMode((int)handle, (int)deviceNumbertoFollow);
  }

/*
 * Class:     com_dmc60c_DMC60CJNI
 * Method:    SetPIDSlot
 * Signature: (II)V
 */
JNIEXPORT void JNICALL Java_com_dmc60c_DMC60CJNI_SetPIDSlot
  (JNIEnv *env, jclass jcls, jint handle, jint slot){
	  c_DMC60C_setPIDSlot((int)handle, (int)slot);
  }

/*
 * Class:     com_dmc60c_DMC60CJNI
 * Method:    getP
 * Signature: (II)F
 */
JNIEXPORT jfloat JNICALL Java_com_dmc60c_DMC60CJNI_getP
  (JNIEnv *env, jclass jcls, jint handle, jint slot){
	  return (jfloat)c_DMC60C_getP((int)handle,(int)slot);
  }

/*
 * Class:     com_dmc60c_DMC60CJNI
 * Method:    getI
 * Signature: (II)F
 */
JNIEXPORT jfloat JNICALL Java_com_dmc60c_DMC60CJNI_getI
  (JNIEnv *env, jclass jcls, jint handle, jint slot){
	  return (jfloat)c_DMC60C_getI((int)handle,(int)slot);
  }

/*
 * Class:     com_dmc60c_DMC60CJNI
 * Method:    getD
 * Signature: (II)F
 */
JNIEXPORT jfloat JNICALL Java_com_dmc60c_DMC60CJNI_getD
  (JNIEnv *env, jclass jcls, jint handle, jint slot){
	  return (jfloat)c_DMC60C_getD((int)handle,(int)slot);
  }

/*
 * Class:     com_dmc60c_DMC60CJNI
 * Method:    getF
 * Signature: (II)F
 */
JNIEXPORT jfloat JNICALL Java_com_dmc60c_DMC60CJNI_getF
  (JNIEnv *env, jclass jcls, jint handle, jint slot){
	  return (jfloat)c_DMC60C_getF((int)handle,(int)slot);
  }
/*
 * Class:     com_dmc60c_DMC60CJNI
 * Method:    GetClosedLoopError
 * Signature: (I)D
 */
JNIEXPORT jdouble JNICALL Java_com_dmc60c_DMC60CJNI_GetClosedLoopError
  (JNIEnv *env, jclass jcls, jint handle){
	return (jdouble)c_DMC60C_getClosedLoopError((int)handle);
}
/*
 * Class:     com_dmc60c_DMC60CJNI
 * Method:    SetLimitSwitches
 * Signature: (IZZZ)V
 */
JNIEXPORT void JNICALL Java_com_dmc60c_DMC60CJNI_SetLimitSwitches
  (JNIEnv *env, jclass jcls, jint handle, jboolean overrideEnable, jboolean forwardSwitchEnable, jboolean reverseSwitchEnable){
	  c_DMC60C_setLimitSwitches((int)handle, (bool)overrideEnable, (bool)forwardSwitchEnable, (bool)reverseSwitchEnable);
  }
/*
 * Class:     com_dmc60c_DMC60CJNI
 * Method:    GetFwdLimitSwitch
 * Signature: (I)Z
 */
JNIEXPORT jboolean JNICALL Java_com_dmc60c_DMC60CJNI_GetFwdLimitSwitch
  (JNIEnv *env, jclass jcls, jint handle){
	return (jboolean)c_DMC60C_getFwdLimitSwitch((int)handle);
}
/*
 * Class:     com_dmc60c_DMC60CJNI
 * Method:    GetRevLimitSwitch
 * Signature: (I)Z
 */
JNIEXPORT jboolean JNICALL Java_com_dmc60c_DMC60CJNI_GetRevLimitSwitch
  (JNIEnv *env, jclass jcls, jint handle){
	return (jboolean)c_DMC60C_getRevLimitSwitch((int)handle);
}
/*
 * Class:     com_dmc60c_DMC60CJNI
 * Method:    IsFwdLimitSwitchActive
 * Signature: (I)Z
 */
JNIEXPORT jboolean JNICALL Java_com_dmc60c_DMC60CJNI_IsFwdLimitSwitchActive
  (JNIEnv *env, jclass jcls, jint handle){
	return (jboolean)c_DMC60C_isFwdLimitSwitchActive((int)handle);
}
/*
 * Class:     com_dmc60c_DMC60CJNI
 * Method:    IsRevLimitSwitchActive
 * Signature: (I)Z
 */
JNIEXPORT jboolean JNICALL Java_com_dmc60c_DMC60CJNI_IsRevLimitSwitchActive
  (JNIEnv *env, jclass jcls, jint handle){
	return (jboolean)c_DMC60C_isRevLimitSwitchActive((int)handle);
}
/*
 * Class:     com_dmc60c_DMC60CJNI
 * Method:    IsOverTempFaultActive
 * Signature: (I)Z
 */
JNIEXPORT jboolean JNICALL Java_com_dmc60c_DMC60CJNI_IsOverTempFaultActive
  (JNIEnv *env, jclass jcls, jint handle){
	return (jboolean)c_DMC60C_isOverTempFaultActive((int)handle);
}

/*
 * Class:     com_dmc60c_DMC60CJNI
 * Method:    IsUnderVoltageFaultActive
 * Signature: (I)Z
 */
JNIEXPORT jboolean JNICALL Java_com_dmc60c_DMC60CJNI_IsUnderVoltageFaultActive
  (JNIEnv *env, jclass jcls, jint handle){
	return (jboolean)c_DMC60C_isUnderVoltageFaultActive((int)handle);
}

/*
 * Class:     com_dmc60c_DMC60CJNI
 * Method:    IsGateDriveFaultActive
 * Signature: (I)Z
 */
JNIEXPORT jboolean JNICALL Java_com_dmc60c_DMC60CJNI_IsGateDriveFaultActive
  (JNIEnv *env, jclass jcls, jint handle){
	return (jboolean)c_DMC60C_isGateDriveFaultActive((int)handle);
}
/*
 * Class:     com_dmc60c_DMC60CJNI
 * Method:    SetBrakeCoast
 * Signature: (IZZ)V
 */
JNIEXPORT void JNICALL Java_com_dmc60c_DMC60CJNI_SetBrakeCoast
  (JNIEnv *env, jclass jcls, jint handle, jboolean overrideEnable, jboolean brakeEnable){
	  c_DMC60C_setBrakeCoast((int)handle, (bool)overrideEnable, (bool)brakeEnable);
  }

/*
 * Class:     com_dmc60c_DMC60CJNI
 * Method:    GetBusVoltage
 * Signature: (I)F
 */
JNIEXPORT jfloat JNICALL Java_com_dmc60c_DMC60CJNI_GetBusVoltage
  (JNIEnv *env, jclass jcls, jint handle){
	  return (jfloat)c_DMC60C_getBusVoltage((int)handle);
  }

/*
 * Class:     com_dmc60c_DMC60CJNI
 * Method:    GetAIN1Voltage
 * Signature: (I)F
 */
JNIEXPORT jfloat JNICALL Java_com_dmc60c_DMC60CJNI_GetAIN1Voltage
  (JNIEnv *env, jclass jcls, jint handle){
	  return (jfloat)c_DMC60C_getAIN1Voltage((int)handle);
  }

/*
 * Class:     com_dmc60c_DMC60CJNI
 * Method:    GetLoadCurrent
 * Signature: (I)F
 */
JNIEXPORT jfloat JNICALL Java_com_dmc60c_DMC60CJNI_GetLoadCurrent
  (JNIEnv *env, jclass jcls, jint handle){
	  return (jfloat)c_DMC60C_getLoadCurrent((int)handle);
  }

/*
 * Class:     com_dmc60c_DMC60CJNI
 * Method:    GetAmbientTemp
 * Signature: (I)F
 */
JNIEXPORT jfloat JNICALL Java_com_dmc60c_DMC60CJNI_GetAmbientTemp
  (JNIEnv *env, jclass jcls, jint handle){
	  return (jfloat)c_DMC60C_getAmbientTemp((int)handle);
  }

/*
 * Class:     com_dmc60c_DMC60CJNI
 * Method:    ZeroEncoderPosition
 * Signature: (I)I
 */
JNIEXPORT jint JNICALL Java_com_dmc60c_DMC60CJNI_ZeroEncoderPosition
  (JNIEnv *env, jclass jcls, jint handle){
	  return (jint)c_DMC60C_zeroEncoderPosition((int)handle);
  }
/*
 * Class:     com_dmc60c_DMC60CJNI
 * Method:    GetRevolutionsTraveled
 * Signature: (I)D
 */
JNIEXPORT jdouble JNICALL Java_com_dmc60c_DMC60CJNI_GetRevolutionsTraveled
  (JNIEnv *env, jclass jcls, jint handle){
	return (jdouble)c_DMC60C_getRevolutionsTraveled((int)handle);
}

/*
 * Class:     com_dmc60c_DMC60CJNI
 * Method:    GetDistanceTraveled
 * Signature: (I)D
 */
JNIEXPORT jdouble JNICALL Java_com_dmc60c_DMC60CJNI_GetDistanceTraveled
  (JNIEnv *env, jclass jcls, jint handle){
	return (jdouble)c_DMC60C_getDistanceTraveled((int)handle);
}
/*
 * Class:     com_dmc60c_DMC60CJNI
 * Method:    GetMetersPerSecond
 * Signature: (I)D
 */
JNIEXPORT jdouble JNICALL Java_com_dmc60c_DMC60CJNI_GetMetersPerSecond
  (JNIEnv *env, jclass jcls, jint handle){
	  return (jdouble)c_DMC60C_getMetersPerSecond((int)handle);
  }

/*
 * Class:     com_dmc60c_DMC60CJNI
 * Method:    GetCurrentDutyCycle
 * Signature: (I)D
 */
JNIEXPORT jdouble JNICALL Java_com_dmc60c_DMC60CJNI_GetCurrentDutyCycle
  (JNIEnv *env, jclass jcls, jint handle){
	  return (jdouble)c_DMC60C_getCurrentDutyCycle((int)handle);
  }
/*
 * Class:     com_dmc60c_DMC60CJNI
 * Method:    GetEncoderPositionCount
 * Signature: (I)I
 */
JNIEXPORT jint JNICALL Java_com_dmc60c_DMC60CJNI_GetEncoderPositionCount
  (JNIEnv *env, jclass jcls, jint handle){
	  return (jint)c_DMC60C_getEncoderPositionCount((int)handle);
  }
/*
 * Class:     com_dmc60c_DMC60CJNI
 * Method:    GetEncoderVelocityCount
 * Signature: (I)I
 */
JNIEXPORT jint JNICALL Java_com_dmc60c_DMC60CJNI_GetEncoderVelocityCount
  (JNIEnv *env, jclass jcls, jint handle){
	  return (jint)c_DMC60C_getEncoderVelocityCount((int)handle);
  }

/*
 * Class:     com_dmc60c_DMC60CJNI
 * Method:    DisableMotor
 * Signature: (I)V
 */
JNIEXPORT void JNICALL Java_com_dmc60c_DMC60CJNI_DisableMotor
  (JNIEnv *env, jclass jcls, jint handle){
	  c_DMC60C_disableMotor((int)handle);
  }

/*
 * Class:     com_dmc60c_DMC60CJNI
 * Method:    IsEnabled
 * Signature: (I)Z
 */
JNIEXPORT jboolean JNICALL Java_com_dmc60c_DMC60CJNI_IsEnabled
  (JNIEnv *env, jclass jcls, jint handle){
	  return (jboolean)c_DMC60C_isEnabled((int)handle);
  }

/*
 * Class:     com_dmc60c_DMC60CJNI
 * Method:    InvertEncoder
 * Signature: (IZ)V
 */
JNIEXPORT void JNICALL Java_com_dmc60c_DMC60CJNI_InvertEncoder
  (JNIEnv *env, jclass jcls, jint handle, jboolean isInverted){
	  c_DMC60C_invertEncoder((int)handle, (bool)isInverted);
  }

/*
 * Class:     com_dmc60c_DMC60CJNI
 * Method:    ConfigPositionReset
 * Signature: (IZZZ)V
 */
JNIEXPORT void JNICALL Java_com_dmc60c_DMC60CJNI_ConfigPositionReset
  (JNIEnv *env, jclass jcls, jint handle, jboolean resetOnFwdLimit, jboolean resetOnRevLimit, jboolean resetOnIndex){
	c_DMC60C_configPositionReset((int)handle, (bool)resetOnFwdLimit, (bool)resetOnRevLimit, (bool)resetOnIndex);
}

/*
 * Class:     com_dmc60c_DMC60CJNI
 * Method:    ConfigIndexActiveEdge
 * Signature: (IZ)V
 */
JNIEXPORT void JNICALL Java_com_dmc60c_DMC60CJNI_ConfigIndexActiveEdge
  (JNIEnv *env, jclass jcls, jint handle, jboolean edge){
	c_DMC60C_configIndexActiveEdge((int)handle, (bool)edge);
}

/*
 * Class:     com_dmc60c_DMC60CJNI
 * Method:    SetInverted
 * Signature: (IZ)V
 */
JNIEXPORT void JNICALL Java_com_dmc60c_DMC60CJNI_SetInverted
  (JNIEnv *env, jclass jcls, jint handle, jboolean isInverted){
	  c_DMC60C_SetInverted((int)handle,(bool)isInverted);
  }

/*
 * Class:     com_dmc60c_DMC60CJNI
 * Method:    GetInverted
 * Signature: (I)Z
 */
JNIEXPORT jboolean JNICALL Java_com_dmc60c_DMC60CJNI_GetInverted
  (JNIEnv *env, jclass jcls, jint handle){
	  return (jboolean)c_DMC60C_GetInverted((int)handle);
  }

