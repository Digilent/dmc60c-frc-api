#include "digilent/DMC60/DMC60C.h"
#include "HAL/HAL.h"
#include "FRC_NetworkCommunication/FRCComm.h"

#if(defined(__FRC_ROBORIO__) && __FRC_ROBORIO__ == 2019)
#define FRCWATCHDOG if(FRC_NetworkCommunication_getWatchdogActive())
#else
#define FRCWATCHDOG HAL_GetControlWord(&controlWord); if(controlWord.enabled)
#endif

namespace DMC60{

HAL_ControlWord controlWord;

DMC60C::DMC60C(int deviceNumber):
	_DMC60LowLevel(new DMC60LowLevel(deviceNumber)),
	_deviceNumber(deviceNumber),
	_wheelDiametermm(0),
	_gearRatio(0),
	_encoderTicks(0),
	_controlMode(ControlMode::Voltage),
	_isEnabled(0),
	_isMotorReversed(0),
	_isEncoderReversed(0){

	if(_DMC60LowLevel->getDeviceNumber() ==255){
		char errorStr[128];
		sprintf(errorStr, "ERROR: Did not find DMC60C with device number %d", deviceNumber);
		HAL_SendError(1, -1, 0, errorStr, __FUNCTION__, "", 1);
	}
	HAL_Report(84, deviceNumber + 1);//TODO: WPI Needs to add DMC60C to tResourceType Enum
	_DMC60LowLevel->sendControl(ControlMode::Disable, 0, 0, 0);
}

DMC60C::DMC60C(int deviceNumber, double wheelDiametermm, double gearRatio, int encoderTicks):
	_DMC60LowLevel(new DMC60LowLevel(deviceNumber)),
	_deviceNumber(deviceNumber),
	_wheelDiametermm(wheelDiametermm),
	_gearRatio(gearRatio),
	_encoderTicks(encoderTicks),
	_controlMode(ControlMode::Voltage),
	_isEnabled(0),
	_isMotorReversed(0),
	_isEncoderReversed(0){

	if(_DMC60LowLevel->getDeviceNumber() ==255){
		char errorStr[128];
		sprintf(errorStr, "ERROR: Did not find DMC60C with device number %d", deviceNumber);
		HAL_SendError(1, -1, 0, errorStr, __FUNCTION__, "", 1);
	}
	HAL_Report(84, deviceNumber + 1);//TODO: WPI Needs to add DMC60C to tResourceType Enum
	_DMC60LowLevel->sendControl(ControlMode::Disable, 0, 0, 0);
}

DMC60C::~DMC60C(){
	_DMC60LowLevel->sendControl(ControlMode::Disable, 0, 0, 0);
}
int DMC60C::getDeviceNumber()const{
	return _deviceNumber;
}

void DMC60C::configWheel(double wheelDiametermm, double gearRatio, int encoderTicks){
	_wheelDiametermm = wheelDiametermm;
	_gearRatio = gearRatio;
	_encoderTicks = encoderTicks;
}
DMC_Code DMC60C::configPID(unsigned int slot, float P, float I, float D, float F){
	DMC_Code status;
	status = _DMC60LowLevel->configPID_kP(slot, P, 100);
	if(status!=DMC_OK){
		HAL_SendError(status , status, 0, getErrorMessage(status), __FUNCTION__, "", status!=0);
		return status;
	}
	status = _DMC60LowLevel->configPID_kI(slot, I, 100);
	if(status!=DMC_OK){
		HAL_SendError(status , status, 0, getErrorMessage(status), __FUNCTION__, "", status!=0);
		return status;
	}
	status = _DMC60LowLevel->configPID_kD(slot, D, 100);
	if(status!=DMC_OK){
		HAL_SendError(status , status, 0, getErrorMessage(status), __FUNCTION__, "", status!=0);
		return status;
	}
	status = _DMC60LowLevel->configPID_kF(slot, F, 100);
	if(status!=DMC_OK){
		HAL_SendError(status , status, 0, getErrorMessage(status), __FUNCTION__, "", status!=0);
		return status;
	}
	return status;
}

DMC_Code DMC60C::configClosedLoopRampRate(unsigned int slot, unsigned int rampRate){
	DMC_Code status;
	status = _DMC60LowLevel->configPID_RampRate(slot, rampRate, 100);
	if(status!=DMC_OK)HAL_SendError(status, status, 0, getErrorMessage(status), __FUNCTION__, "", status!=0);
	return status;
}

void DMC60C::configOpenLoopRampRate(unsigned short rampRate){
	_DMC60LowLevel->setRampRate(rampRate);
}
DMC_Code DMC60C::setContinuousCurrentLimit(double currentAmps){
	DMC_Code status;
	status = _DMC60LowLevel->setContinuousCurrentLimit(currentAmps);
	if(status!=DMC_OK)HAL_SendError(status, status, 0, getErrorMessage(status), __FUNCTION__, "", status!=0);
	return status;
}
DMC_Code DMC60C::setPeakCurrentLimit(double currentAmps){
	DMC_Code status;
	status = _DMC60LowLevel->setPeakCurrentLimit(currentAmps);
	if(status!=DMC_OK)HAL_SendError(status, status, 0, getErrorMessage(status), __FUNCTION__, "", status!=0);
	return status;
}
DMC_Code DMC60C::setPeakCurrentDuration(int durationMs){
	DMC_Code status;
	status = _DMC60LowLevel->setPeakCurrentDuration(durationMs);
	if(status!=DMC_OK)HAL_SendError(status, status, 0, getErrorMessage(status), __FUNCTION__, "", status!=0);
	return status;
}
DMC_Code DMC60C::enableCurrentLimiting(bool enabled){
	DMC_Code status;
	status = _DMC60LowLevel->enableCurrentLimit(enabled);
	if(status!=DMC_OK)HAL_SendError(status, status, 0, getErrorMessage(status), __FUNCTION__, "", status!=0);
	return status;
}
ControlMode DMC60C::getControlMode(){
	STSGENERAL generalStatus;
	DMC_Code status;
	status = _DMC60LowLevel->getGeneralStatus(&generalStatus);
	if(status!=DMC_OK)HAL_SendError(status, status, 0, getErrorMessage(status), __FUNCTION__, "", status!=0);
	return (ControlMode)generalStatus.modeSelect;
}

void DMC60C::driveVoltage(double percentVoltage){
	FRCWATCHDOG{
		int dutycycle= percentVoltage/100 * 32767;
		_DMC60LowLevel->sendControl(ControlMode::Voltage, dutycycle);
		_isEnabled=true;
	}
}

void DMC60C::drivePosition(double revolutions){
	FRCWATCHDOG{
		int ticks;
		ticks = _gearRatio * _encoderTicks*4 * revolutions;
		_DMC60LowLevel->sendControl(ControlMode::Position, ticks);
		_isEnabled=true;
	}
}
void DMC60C::driveDistance(double meters){
	FRCWATCHDOG{
		int ticks;
		ticks = _gearRatio * _encoderTicks*4 * meters / (3.141592653 * _wheelDiametermm / 1000);
		_DMC60LowLevel->sendControl(ControlMode::Position, ticks);
		_isEnabled=true;
	}
}
void DMC60C::driveVelocity(double metersPerSecond){
	FRCWATCHDOG{
		int velcnt = 400*metersPerSecond*_gearRatio*_encoderTicks/(3.1415926535 * _wheelDiametermm);
		_DMC60LowLevel->sendControl(ControlMode::Velocity, velcnt);
		_isEnabled=true;
	}
}

void DMC60C::followerMode(int deviceNumbertoFollow){
	FRCWATCHDOG{
		_DMC60LowLevel->sendControl(ControlMode::SlaveFollower, deviceNumbertoFollow);
		_isEnabled=true;
	}
}

void DMC60C::driveVoltageCompensation(double voltage){
	FRCWATCHDOG{
		_DMC60LowLevel->sendControl(ControlMode::VoltageCompensation, voltage);
		_isEnabled=true;
	}
}

void DMC60C::driveCurrent(double currentAmps){
	FRCWATCHDOG{
		_DMC60LowLevel->sendControl(ControlMode::Current, currentAmps);
		_isEnabled=true;
	}
}

void DMC60C::setPIDSlot(unsigned int slot){
	_DMC60LowLevel->setPIDSlot(slot);
}
float DMC60C::getP(unsigned int slot){
	float val;
	DMC_Code status;
	status = _DMC60LowLevel->get_kP(0, &val, 100);
	if(status!=DMC_OK)HAL_SendError(status, status, 0, getErrorMessage(status), __FUNCTION__, "", status!=0);
	return val;
}
float DMC60C::getI(unsigned int slot){
	float val;
	DMC_Code status;
	status = _DMC60LowLevel->get_kI(0, &val, 100);
	if(status!=DMC_OK)HAL_SendError(status, status, 0, getErrorMessage(status), __FUNCTION__, "", status!=0);
	return val;
}
float DMC60C::getD(unsigned int slot){
	float val;
	DMC_Code status;
	status = _DMC60LowLevel->get_kD(0, &val, 100);
	if(status!=DMC_OK)HAL_SendError(status, status, 0, getErrorMessage(status), __FUNCTION__, "", status!=0);
	return val;
}
float DMC60C::getF(unsigned int slot){
	float val;
	DMC_Code status;
	status = _DMC60LowLevel->get_kF(0, &val, 100);
	if(status!=DMC_OK)HAL_SendError(status, status, 0, getErrorMessage(status), __FUNCTION__, "", status!=0);
	return val;
}
double DMC60C::getClosedLoopError(){
	STSGENERAL generalStatus;
	DMC_Code status;
	float closedLoopError=0;
	int c=0;
	status = _DMC60LowLevel->getGeneralStatus(&generalStatus);
	if(status!=DMC_OK)HAL_SendError(status, status, 0, getErrorMessage(status), __FUNCTION__, "", status!=0);
	switch((ControlMode)generalStatus.modeSelect){
		case ControlMode::Voltage:
			closedLoopError = (signed char)(generalStatus.ClosedLoopErrorM)*256 + generalStatus.ClosedLoopErrorL;
			break;
		case ControlMode::Disable:
			break;
		case ControlMode::Velocity:
			//Fall through
		case ControlMode::Position:
			c = (signed char)generalStatus.ClosedLoopErrorH*65536 + generalStatus.ClosedLoopErrorM*256 + generalStatus.ClosedLoopErrorL;
			closedLoopError = c;
			break;
		case ControlMode::Current:
			//Fall through
		case ControlMode::VoltageCompensation:
			closedLoopError = (signed char)generalStatus.ClosedLoopErrorH + (float)(generalStatus.ClosedLoopErrorM)/256 + (float)(generalStatus.ClosedLoopErrorL)/65536;
			break;
		default:
		break;
	}
	closedLoopError = (generalStatus.fDivErrby256) ? closedLoopError*256 : closedLoopError;
	return closedLoopError;
}
void DMC60C::setLimitSwitches(bool overrideEnable, bool forwardSwitchEnable, bool reverseSwitchEnable){
	_DMC60LowLevel->setLimitSwitchOverride(overrideEnable, forwardSwitchEnable, reverseSwitchEnable);
}
bool DMC60C::getFwdLimitSwitch(){
	STSGENERAL generalStatus;
	DMC_Code status;
	status = _DMC60LowLevel->getGeneralStatus(&generalStatus);
	if(status!=DMC_OK)HAL_SendError(status, status, 0, getErrorMessage(status), __FUNCTION__, "", status!=0);
	return (generalStatus.fFwdLimitPin);
}
bool DMC60C::getRevLimitSwitch(){
	STSGENERAL generalStatus;
	DMC_Code status;
	status = _DMC60LowLevel->getGeneralStatus(&generalStatus);
	if(status!=DMC_OK)HAL_SendError(status, status, 0, getErrorMessage(status), __FUNCTION__, "", status!=0);
	return (generalStatus.fRevLimitPin);
}
bool DMC60C::isFwdLimitSwitchActive(){
	STSGENERAL generalStatus;
	DMC_Code status;
	status = _DMC60LowLevel->getGeneralStatus(&generalStatus);
	if(status!=DMC_OK)HAL_SendError(status, status, 0, getErrorMessage(status), __FUNCTION__, "", status!=0);
	return (generalStatus.fFwdLimitHit);
}
bool DMC60C::isRevLimitSwitchActive(){
	STSGENERAL generalStatus;
	DMC_Code status;
	status = _DMC60LowLevel->getGeneralStatus(&generalStatus);
	if(status!=DMC_OK)HAL_SendError(status, status, 0, getErrorMessage(status), __FUNCTION__, "", status!=0);
	return (generalStatus.fRevLimitHit);
}
LimitSwitch DMC60C::getFwdLimitSwitchStatus(){
	STSGENERAL generalStatus;
	DMC_Code status;
	LimitSwitch fwdSwitch;
	status = _DMC60LowLevel->getGeneralStatus(&generalStatus);
	if(status!=DMC_OK)HAL_SendError(status, status, 0, getErrorMessage(status), __FUNCTION__, "", status!=0);
	fwdSwitch.SwitchType = (generalStatus.fFwdLimitDisabled)?LimitSwitchType::DISABLED :\
			(generalStatus.fFwdLimitNormalClosed) ? LimitSwitchType::NORMALLY_CLOSED : LimitSwitchType::NORMALLY_OPEN;
	fwdSwitch.activeState = generalStatus.fFwdLimitHit;
	fwdSwitch.pinState = generalStatus.fFwdLimitPin;
	fwdSwitch.overridden = generalStatus.fFwdLimitDisableOverride & generalStatus.fFwdRevLimitOverride;
	return fwdSwitch;
}
LimitSwitch DMC60C::getRevLimitSwitchStatus(){
	STSGENERAL generalStatus;
	DMC_Code status;
	LimitSwitch revSwitch;
	status = _DMC60LowLevel->getGeneralStatus(&generalStatus);
	if(status!=DMC_OK)HAL_SendError(status, status, 0, getErrorMessage(status), __FUNCTION__, "", status!=0);
	revSwitch.SwitchType = (generalStatus.fRevLimitDisabled)?LimitSwitchType::DISABLED :\
			(generalStatus.fRevLimitNormalClosed) ? LimitSwitchType::NORMALLY_CLOSED : LimitSwitchType::NORMALLY_OPEN;
	revSwitch.activeState = generalStatus.fRevLimitHit;
	revSwitch.pinState = generalStatus.fRevLimitPin;
	revSwitch.overridden = generalStatus.fRevLimitDisableOverride & generalStatus.fFwdRevLimitOverride;
	return revSwitch;
}
bool DMC60C::isCurrentLimitActive(){
	STSGENERAL generalStatus;
	DMC_Code status;
	status = _DMC60LowLevel->getGeneralStatus(&generalStatus);
	if(status!=DMC_OK)HAL_SendError(status, status, 0, getErrorMessage(status), __FUNCTION__, "", status!=0);
	return generalStatus.fCurrentLimitActive;
}
bool DMC60C::isOverTempFaultActive(){
	STSGENERAL generalStatus;
	DMC_Code status;
	status = _DMC60LowLevel->getGeneralStatus(&generalStatus);
	if(status!=DMC_OK)HAL_SendError(status, status, 0, getErrorMessage(status), __FUNCTION__, "", status!=0);
	return generalStatus.fOverTempFault;
}
bool DMC60C::isUnderVoltageFaultActive(){
	STSGENERAL generalStatus;
	DMC_Code status;
	status = _DMC60LowLevel->getGeneralStatus(&generalStatus);
	if(status!=DMC_OK)HAL_SendError(status, status, 0, getErrorMessage(status), __FUNCTION__, "", status!=0);
	return generalStatus.fUndervoltageFault;
}
bool DMC60C::isGateDriveFaultActive(){
	STSGENERAL generalStatus;
	DMC_Code status;
	status = _DMC60LowLevel->getGeneralStatus(&generalStatus);
	if(status!=DMC_OK)HAL_SendError(status, status, 0, getErrorMessage(status), __FUNCTION__, "", status!=0);
	return generalStatus.fGateDriverFault;
}
void DMC60C::setBrakeCoast(bool overrideEnable, bool brakeEnable){
	_DMC60LowLevel->setOverrideBC(overrideEnable, brakeEnable);
}

float DMC60C::getBusVoltage(){
	STSANALOG analogStatus;
	DMC_Code status;
	status = _DMC60LowLevel->getAnalogStatus(&analogStatus);
	if(status!=DMC_OK)HAL_SendError(status, status, 0, getErrorMessage(status), __FUNCTION__, "", status!=0);
	return (float)(analogStatus.vltgVbus)/256;
}
float DMC60C::getAIN1Voltage(){
	STSANALOG analogStatus;
	DMC_Code status;
	status = _DMC60LowLevel->getAnalogStatus(&analogStatus);
	if(status!=DMC_OK)HAL_SendError(status, status, 0, getErrorMessage(status), __FUNCTION__, "", status!=0);
	return (float)(analogStatus.vltgAnalogIn)/256;
}
float DMC60C::getLoadCurrent(){
	STSANALOG analogStatus;
	DMC_Code status;
	status = _DMC60LowLevel->getAnalogStatus(&analogStatus);
	if(status!=DMC_OK)HAL_SendError(status, status, 0, getErrorMessage(status), __FUNCTION__, "", status!=0);
	return (float)(analogStatus.crntOutput)/256;
}
float DMC60C::getAmbientTemp(){
	STSANALOG analogStatus;
	DMC_Code status;
	status = _DMC60LowLevel->getAnalogStatus(&analogStatus);
	if(status!=DMC_OK)HAL_SendError(status, status, 0, getErrorMessage(status), __FUNCTION__, "", status!=0);
	return (float)(analogStatus.tmpAmbient)/256;
}

DMC_Code DMC60C::zeroEncoderPosition(){
	DMC_Code status;
	status = _DMC60LowLevel->setEncoderPosition(0, 200);
	if(status!=DMC_OK)HAL_SendError(status, status, 0, getErrorMessage(status), __FUNCTION__, "", status!=0);
	return status;
}

int DMC60C::getEncoderPositionCount(){
	STSENCODER encoderStatus;
	DMC_Code status;
	int ret;
	status = _DMC60LowLevel->getEncoderStatus(&encoderStatus);
	if(status!=DMC_OK)HAL_SendError(status, status, 0, getErrorMessage(status), __FUNCTION__, "", status!=0);
	ret = (signed char)encoderStatus.poscntH;
	ret = ret<<16;
	ret |= (int)(encoderStatus.poscntM)<<8 | (int)encoderStatus.poscntL;
	ret = (encoderStatus.fDivPosBy8) ? ret * 8: ret;
	return ret;
}
double DMC60C::getRevolutionsTraveled(){
	return (double)getEncoderPositionCount() / _encoderTicks / 4 / _gearRatio;
}
double DMC60C::getDistanceTraveled(){
	return (double)getEncoderPositionCount() / _encoderTicks / 4 / _gearRatio * (3.1415926535 * _wheelDiametermm / 1000);
}
int DMC60C::getEncoderVelocityCount(){
	STSENCODER encoderStatus;
	DMC_Code status;
	status = _DMC60LowLevel->getEncoderStatus(&encoderStatus);
	if(status!=DMC_OK)HAL_SendError(status, status, 0, getErrorMessage(status), __FUNCTION__, "", status!=0);
	return (encoderStatus.fDivVelBy4) ? (signed short)(encoderStatus.velcntH<<8 | encoderStatus.velcntL)*4 : (signed short)(encoderStatus.velcntH<<8 | encoderStatus.velcntL);
}

double DMC60C::getMetersPerSecond(){
	int velcnt;
	double MPS;
	velcnt = getEncoderVelocityCount();
	MPS = (double)velcnt * (3.141592653 * _wheelDiametermm) / 400/ _gearRatio/_encoderTicks;
	return MPS;
}

double DMC60C::getCurrentDutyCycle() const {
	STSGENERAL generalStatus;
	DMC_Code status;
	FRCWATCHDOG{
		status = _DMC60LowLevel->getGeneralStatus(&generalStatus);
		if(status!=DMC_OK)HAL_SendError(status, status, 0, getErrorMessage(status), __FUNCTION__, "", status!=0);
		if(generalStatus.currentDuty <= -32510)generalStatus.currentDuty=-32767;
		return (double)generalStatus.currentDuty*100/32767;
	}
	else{
		return 0;
	}
}

void DMC60C::disableMotor(){

	_DMC60LowLevel->sendControl(ControlMode::Disable, 0, 0, 0);
	_isEnabled=false;

}

bool DMC60C::isEnabled(){
	return _isEnabled;
}

void DMC60C::invertEncoder(bool isInverted){
	_isEncoderReversed=isInverted;
	_DMC60LowLevel->setReverseFeedbackSensor(isInverted);
}
void DMC60C::configPositionReset(bool resetOnFwdLimit, bool resetOnRevLimit, bool resetOnIndex){
	_DMC60LowLevel->setClearPositionOnFwdLimit(resetOnFwdLimit, 100);
	_DMC60LowLevel->setClearPositionOnRevLimit(resetOnRevLimit, 100);
	_DMC60LowLevel->setClearPositionOnIndex(resetOnIndex, 100);

}
void DMC60C::configIndexActiveEdge(bool edge){
	_DMC60LowLevel->setIndexActiveEdge(edge, 100);
}
const char* DMC60C::getErrorMessage(DMC_Code Error) const{
	switch(Error){
	case DMC_Code::DMC_OK:
		return "";
	case DMC_Code::DMC_ParamInvalid:
		return "Error: Invalid parameter";
	case DMC_Code::DMC_ParamValueInvalid:
		return "Error: Invalid parameter value";
	case DMC_Code::DMC_RxTimeout:
		return "Error: RX Timeout";
	case DMC_Code::DMC_TxFail:
		return "Error: TX Failed";
	case DMC_Code::DMC_TxTimeout:
		return "Error: TX Timeout";
	case DMC_Code::DMC_VCMDAckReset:
		return "Error: DMC has reset";
	case DMC_Code::DMC_VCMDBadParameter:
		return "Error: Invalid vendor command parameter";
	case DMC_Code::DMC_VCMDCrcMismatch:
		return "Error: Vendor Command CRC mismatch";
	case DMC_Code::DMC_VCMDDataRcvMore:
		return "Error: DMC60C received more data than was specified";
	case DMC_Code::DMC_VCMDFlashWriteFailed:
		return "Error: Flash write failed";
	case DMC_Code::DMC_VCMDInBootloader:
		return "Error: DMC60C is in bootloader mode";
	case DMC_Code::DMC_VCMDNotSupported:
		return "Error: Vendor command not supported";
	default:
		return "Error: Unknown error";
	}
}
void DMC60C::SetInverted(bool isInverted){
	_isMotorReversed=isInverted;
	_DMC60LowLevel->setReverse(isInverted);
}
bool DMC60C::GetInverted() const{
	return _isMotorReversed;
}




static std::vector<DMC60C*> c_DMC;

extern"C"{
//
int c_DMC60C_Create1(int deviceNumber){
	c_DMC.push_back(new DMC60C(deviceNumber));
	return std::distance(c_DMC.begin(), c_DMC.end()-1);
}
int c_DMC60C_Create2(int deviceNumber, double wheelDiametermm, double gearRatio, int encoderTicks){
	c_DMC.push_back(new DMC60C(deviceNumber, wheelDiametermm, gearRatio, encoderTicks));
	return std::distance(c_DMC.begin(), c_DMC.end()-1);
}
void c_DMC60C_Destroy(int dev){
	std::vector<DMC60C*>::iterator i = c_DMC.begin()+dev;
	delete c_DMC[dev];
	c_DMC.erase(i);
}

void c_DMC60C_configWheel(int dev, double wheelDiametermm, double gearRatio, int encoderTicks){
	c_DMC[dev]->configWheel(wheelDiametermm, gearRatio, encoderTicks);
}
DMC_Code c_DMC60C_configPID(int dev, unsigned int slot, float P, float I, float D, float F){
	return c_DMC[dev]->configPID(slot, P, I, D, F);
}

DMC_Code c_DMC60C_configClosedLoopRampRate(int dev, unsigned int slot, unsigned int rampRate){
	return c_DMC[dev]->configClosedLoopRampRate(slot, rampRate);
}
void c_DMC60C_configOpenLoopRampRate(int dev, unsigned short rampRate){
	c_DMC[dev]->configOpenLoopRampRate(rampRate);
}
DMC_Code c_DMC60C_setContinuousCurrentLimit(int dev, double currentAmps){
	return c_DMC[dev]->setContinuousCurrentLimit(currentAmps);
}
DMC_Code c_DMC60C_setPeakCurrentLimit(int dev, double currentAmps){
	return c_DMC[dev]->setPeakCurrentLimit(currentAmps);
}
DMC_Code c_DMC60C_setPeakCurrentDuration(int dev, int durationMs){
	return c_DMC[dev]->setPeakCurrentDuration(durationMs);
}
DMC_Code c_DMC60C_enableCurrentLimiting(int dev, bool enabled){
	return c_DMC[dev]->enableCurrentLimiting(enabled);
}

ControlMode c_DMC60C_getControlMode(int dev){
	return c_DMC[dev]->getControlMode();
}

void c_DMC60C_driveVoltage(int dev, double percentVoltage){
	c_DMC[dev]->driveVoltage(percentVoltage);
}
void c_DMC60C_drivePosition(int dev, double revolutions){
	c_DMC[dev]->drivePosition(revolutions);
}
void c_DMC60C_driveDistance(int dev, double meters){
	c_DMC[dev]->driveDistance(meters);
}
void c_DMC60C_driveVelocity(int dev, double metersPerSecond){
	c_DMC[dev]->driveVelocity(metersPerSecond);
}
void c_DMC60C_driveVoltageCompensation(int dev, double voltage){
	c_DMC[dev]->driveVoltageCompensation(voltage);
}
void c_DMC60C_driveCurrent(int dev, double currentAmps){
	c_DMC[dev]->driveCurrent(currentAmps);
}
void c_DMC60C_followerMode(int dev, int deviceNumbertoFollow){
	c_DMC[dev]->followerMode(deviceNumbertoFollow);
}
void c_DMC60C_setPIDSlot(int dev, unsigned int slot){
	c_DMC[dev]->setPIDSlot(slot);
}
float c_DMC60C_getP(int dev, unsigned int slot){
	return c_DMC[dev]->getP(slot);
}
float c_DMC60C_getI(int dev, unsigned int slot){
	return c_DMC[dev]->getI(slot);
}
float c_DMC60C_getD(int dev, unsigned int slot){
	return c_DMC[dev]->getD(slot);
}
float c_DMC60C_getF(int dev, unsigned int slot){
	return c_DMC[dev]->getF(slot);
}
double c_DMC60C_getClosedLoopError(int dev){
	return c_DMC[dev]->getClosedLoopError();
}

void c_DMC60C_setLimitSwitches(int dev, bool overrideEnable, bool forwardSwitchEnable, bool reverseSwitchEnable){
	return c_DMC[dev]->setLimitSwitches(overrideEnable, forwardSwitchEnable, reverseSwitchEnable);
}
bool c_DMC60C_getFwdLimitSwitch(int dev){
	return c_DMC[dev]->getFwdLimitSwitch();
}
bool c_DMC60C_getRevLimitSwitch(int dev){
	return c_DMC[dev]->getRevLimitSwitch();
}
bool c_DMC60C_isFwdLimitSwitchActive(int dev){
	return c_DMC[dev]->isFwdLimitSwitchActive();
}
bool c_DMC60C_isRevLimitSwitchActive(int dev){
	return c_DMC[dev]->isRevLimitSwitchActive();
}
LimitSwitch c_DMC60C_getFwdLimitSwitchStatus(int dev){
	return c_DMC[dev]->getFwdLimitSwitchStatus();
}
LimitSwitch c_DMC60C_getRevLimitSwitchStatus(int dev){
	return c_DMC[dev]->getRevLimitSwitchStatus();
}
bool c_DMC60C_isCurrentLimitActive(int dev){
	return c_DMC[dev]->isCurrentLimitActive();
}
bool c_DMC60C_isOverTempFaultActive(int dev){
	return c_DMC[dev]->isOverTempFaultActive();
}
bool c_DMC60C_isUnderVoltageFaultActive(int dev){
	return c_DMC[dev]->isUnderVoltageFaultActive();
}
bool c_DMC60C_isGateDriveFaultActive(int dev){
	return c_DMC[dev]->isGateDriveFaultActive();
}

void c_DMC60C_setBrakeCoast(int dev, bool overrideEnable, bool brakeEnable){
	c_DMC[dev]->setBrakeCoast(overrideEnable, brakeEnable);
}

float c_DMC60C_getBusVoltage(int dev){
	return c_DMC[dev]->getBusVoltage();
}
float c_DMC60C_getAIN1Voltage(int dev){
	return c_DMC[dev]->getAIN1Voltage();
}
float c_DMC60C_getLoadCurrent(int dev){
	return c_DMC[dev]->getLoadCurrent();
}
float c_DMC60C_getAmbientTemp(int dev){
	return c_DMC[dev]->getAmbientTemp();
}

DMC_Code c_DMC60C_zeroEncoderPosition(int dev){
	return c_DMC[dev]->zeroEncoderPosition();
}
double c_DMC60C_getRevolutionsTraveled(int dev){
	return c_DMC[dev]->getRevolutionsTraveled();
}
double c_DMC60C_getDistanceTraveled(int dev){
	return c_DMC[dev]->getDistanceTraveled();
}
double c_DMC60C_getMetersPerSecond(int dev){
	return c_DMC[dev]->getMetersPerSecond();
}
double c_DMC60C_getCurrentDutyCycle(int dev){
	return c_DMC[dev]->getCurrentDutyCycle();
}
int c_DMC60C_getEncoderPositionCount(int dev){
	return c_DMC[dev]->getEncoderPositionCount();
}
int c_DMC60C_getEncoderVelocityCount(int dev){
	return c_DMC[dev]->getEncoderVelocityCount();
}
void c_DMC60C_disableMotor(int dev){
	c_DMC[dev]->disableMotor();
}

bool c_DMC60C_isEnabled(int dev){
	return c_DMC[dev]->isEnabled();
}
void c_DMC60C_invertEncoder(int dev, bool isInverted){
	c_DMC[dev]->invertEncoder(isInverted);
}
void c_DMC60C_configPositionReset(int dev, bool resetOnFwdLimit, bool resetOnRevLimit, bool resetOnIndex){
	c_DMC[dev]->configPositionReset(resetOnFwdLimit, resetOnRevLimit, resetOnIndex);
}
void c_DMC60C_configIndexActiveEdge(int dev, bool edge){
	c_DMC[dev]->configIndexActiveEdge(edge);
}

void c_DMC60C_SetInverted(int dev, bool isInverted){
	c_DMC[dev]->SetInverted(isInverted);
}
bool c_DMC60C_GetInverted(int dev){
	return c_DMC[dev]->GetInverted();
}


}


}
