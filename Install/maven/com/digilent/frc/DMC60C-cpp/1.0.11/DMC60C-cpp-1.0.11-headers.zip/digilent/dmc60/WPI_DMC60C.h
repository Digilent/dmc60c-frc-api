#include "frc/MotorSafety.h"
#include "frc/SpeedController.h"
#include "frc/SmartDashboard/SendableBase.h"
#include "frc/SmartDashboard/SendableBuilder.h"
#include "digilent/dmc60/DMC60C.h"
#include "HAL/HAL.h"

namespace DMC60{
/**
 * \class WPI_DMC60C
 *
 * \brief High Level DMC60C Interface
 *
 * This class contains all of the high level functions
 * used to communicate with the DMC60C.
 */
class WPI_DMC60C:
			public virtual DMC60C,
			public virtual frc::MotorSafety,
			public frc::SpeedController,
			public frc::SendableBase
{
public:

	/**
	 * \fn WPI_DMC60C(int deviceNumber)
	 * \brief Creates a DMC60C object for use in an open loop setup
	 * \param deviceNumber The deviceNumber of the DMC60C Motor
	 */
	WPI_DMC60C(int deviceNumber);
	/**
	 * \fn WPI_DMC60C(int deviceNumber, double wheelDiametermm, double gearRatio, int encoderTicks)
	 * \brief Creates a DMC60C object for use in a closed loop setup
	 * \param deviceNumber The deviceNumber of the DMC60C Motor
	 * \param wheelDiametermm The diameter of the wheel attached to the DMC60C in millimeters.
	 * \param gearRatio The ratio of the gearbox (EX: 12 if using a 12:1 gearbox)
	 * \param encoderTicks The number of pulses per channel per revolution on the quadrature encoder attached to the DMC60C motor.
	 */
	WPI_DMC60C(int deviceNumber, double wheelDiametermm, double gearRatio, int encoderTicks);
	~WPI_DMC60C();

	//SpeedController
	/**
	 * \fn void Set(double speed)
	 * \brief Set command used in WPI Speedcontroller class. Sets the speed to the specified duty cycle.
	 * \param speed Duty cycle (-1.0 to 1.0)
	 */
	void Set(double speed) override;
	/**
	 * \fn double Get()
	 * \brief Get command used in WPI Speedcontroller class. Gets the current duty cycle.
	 * \return Duty cycle (-1.0 to 1.0)
	 */
	double Get() const override;
	/**
	 * \fn void SetInverted(bool isInverted)
	 * \brief Inverts the motor direction.
	 * \param isInverted If true, motor will spin in reverse direction.
	 */
	void SetInverted(bool isInverted) override;
	/**
	 * \fn bool GetInverted()
	 * \brief Returns whether or not the motor is inverted.
	 * \return True if motor is inverted, false otherwise.
	 */
	bool GetInverted() const override;
	/**
	 * \fn void Disable()
	 * \brief Disable command used in WPI Speedcontroller class. Disables the motor.
	 */
	void Disable() override;

	//PIDOutput
	/**
	 * \fn void PIDWrite(double output)
	 * \brief Virtual function overload from PIDOutput class in SpeedController. Sets the duty cycle.
	 * \param output Signed duty cycle (-1 to 1).
	 */
	void PIDWrite(double output) override;

	//MotorSafety
	/**
	 * \fn void StopMotor()
	 * \brief Stops the motor.
	 */
	void StopMotor() override;

	/**
	 * \fn void GetDescription(wpi::raw_ostream& desc)
	 * \brief Prints the DMC ID to an output stream.
	 * \param desc Address of output stream.
	 */
	void GetDescription(wpi::raw_ostream& desc) const override;

	protected:
	/**
	 * \fn void InitSendable(frc::SendableBuilder& builder)
	 * \brief Initializes the DMC60C for use as a sendable object in the FRC smart dashboard.
	 */
	void InitSendable(frc::SendableBuilder& builder);
	/*private:

	#if!(defined(__FRC_ROBORIO__) && __FRC_ROBORIO__ == 2019)
		std::unique_ptr<MotorSafetyHelper> _MotorSafetyHelper;
	#endif*/

};
}
