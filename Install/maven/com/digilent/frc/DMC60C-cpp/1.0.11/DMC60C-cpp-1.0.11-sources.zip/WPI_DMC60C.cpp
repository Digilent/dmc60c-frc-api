#include "digilent/dmc60/WPI_DMC60C.h"

namespace DMC60{

WPI_DMC60C::WPI_DMC60C(int deviceNumber):
	DMC60C(deviceNumber)
{
	_DMC60LowLevel->sendControl(ControlMode::Disable, 0, 0, 0);
	SetName("DMC60C ", deviceNumber);
	SetSubsystem("Motor Controllers");
}

WPI_DMC60C::WPI_DMC60C(int deviceNumber, double wheelDiametermm, double gearRatio, int encoderTicks):
	DMC60C(deviceNumber,wheelDiametermm,gearRatio,encoderTicks)
	{
	_DMC60LowLevel->sendControl(ControlMode::Disable, 0, 0, 0);
	SetName("DMC60C ", deviceNumber);
	SetSubsystem("Motor Controllers");
}

WPI_DMC60C::~WPI_DMC60C(){
	_DMC60LowLevel->sendControl(ControlMode::Disable, 0, 0, 0);
	SetSafetyEnabled(false);
}

void WPI_DMC60C::Set(double speed){
	driveVoltage(speed*100);
}
double WPI_DMC60C::Get() const{
	return getCurrentDutyCycle()/100;
}
void WPI_DMC60C::SetInverted(bool isInverted){
	_isMotorReversed=isInverted;
	_DMC60LowLevel->setReverse(isInverted);
}
bool WPI_DMC60C::GetInverted() const{
	return _isMotorReversed;
}
void WPI_DMC60C::Disable(){
	disableMotor();
}

void WPI_DMC60C::PIDWrite(double output){
	Set(output);
}
void WPI_DMC60C::StopMotor(){
	_DMC60LowLevel->sendControl(ControlMode::Disable, 0, 0, 0);
	_isEnabled=false;
}
void WPI_DMC60C::GetDescription(wpi::raw_ostream& desc)const{
	desc << "DMC60C ID " << (int)_DMC60LowLevel->getDeviceNumber();
}
void WPI_DMC60C::InitSendable(frc::SendableBuilder& builder){
	builder.SetSmartDashboardType("Speed Controller");
	builder.SetSafeState([=]() {StopMotor();});
	builder.AddDoubleProperty("Duty Cycle", [=](){return Get();}, [=](double value) {Set(value);});
}
}
